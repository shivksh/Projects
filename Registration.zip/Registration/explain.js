




 var body1 = document.getElementById("body");
 var form=document.createElement("form");
 form.setAttribute("id","form1");
 form.setAttribute("onsubmit","return validation()")
 form.setAttribute("method","post");
 var div1=document.createElement("div");
 div1.setAttribute("id","div1");
 div1.appendChild(form)
 var head1=document.createElement("h1");
 var text1=document.createTextNode("Registration Form");
 body.appendChild(div1);
 head1.appendChild(text1);
 form.appendChild(head1);
 div1.setAttribute("style","margin:0px auto;width:30%;");
 head1.setAttribute("style","margin-bottom:10%;margin-left:3%;")
 var lable1=document.createElement("label");
 var input1=document.createElement("input");
 var text2=document.createTextNode("Username :");
 input1.setAttribute("type","text");
 input1.setAttribute("id","input1");
 lable1.appendChild(text2);
 form.appendChild(lable1);
 var br=document.createElement("br");
 form.appendChild(br);
 form.appendChild(input1);
 lable1.setAttribute("id","label11");   
 lable1.setAttribute("style","font-weight:bold;font-size: larger;margin:2%;");
 input1.setAttribute("style","width: 60%;height:30px;margin:3%;");




 // ----------------------------------------------------------------------------------------------------------------






 var br=document.createElement("br");
 form.appendChild(br);
 var lable2=document.createElement("label");
 var input2=document.createElement("input");
 var text3=document.createTextNode("E-mail :");
 input2.setAttribute("type","email");
 input2.setAttribute("id","input2");
 lable2.appendChild(text3);
 form.appendChild(lable2);
 var br=document.createElement("br");
 form.appendChild(br);
 form.appendChild(input2);
 lable2.setAttribute("id","label11");
 lable2.setAttribute("style","font-weight:bold;font-size: larger;margin:2%;");
 input2.setAttribute("style","width: 60%;height:30px;margin:3%;");





 // ------------------------------------------------------------------------------------------------------------------------





 var br=document.createElement("br");
 form.appendChild(br);
 var lable3=document.createElement("label");
 var input3=document.createElement("input");
 var text4=document.createTextNode("Create Password :");
 input3.setAttribute("type","password");
 input3.setAttribute("id","input3");
 lable3.appendChild(text4);
 form.appendChild(lable3);
 var br=document.createElement("br");
 form.appendChild(br);
 form.appendChild(input3);
 lable3.setAttribute("id","label11");
 lable3.setAttribute("style","font-weight:bold;font-size: larger;margin:2%;");
 input3.setAttribute("style","width: 60%;height:30px;margin:3%;");





 
 // --------------------------------------------------------------------------------------------------------------------------------









 var br=document.createElement("br");
 form.appendChild(br);
 var lable4=document.createElement("label");
 var input4=document.createElement("input");
 var text5=document.createTextNode("Confirm Password :");
 input4.setAttribute("type","password");
 input4.setAttribute("id","input4");
 lable4.appendChild(text5);
 form.appendChild(lable4);
 var br=document.createElement("br");
 form.appendChild(br);
 form.appendChild(input4);
 lable4.setAttribute("id","label11");
 lable4.setAttribute("style","font-weight:bold;font-size: larger;margin:2%;");
 input4.setAttribute("style","width: 60%;height:30px;margin:3%;");






// ----------------------------------------------------------------------------------------------------------------------------------------









 var br=document.createElement("br");
 form.appendChild(br);
 var lable5=document.createElement("label");
 var button=document.createElement("button");
 var text6=document.createTextNode("Submit");
 button.setAttribute("type","button");
 button.setAttribute("id","button");
 lable5.appendChild(text6);
 button.appendChild(lable5);
 form.appendChild(button);
 lable5.setAttribute("id","label11");
 lable5.setAttribute("style","font-weight:bold;font-size: larger;");
 button.setAttribute("style","margin:4% 0 0 ; width:70%;height:40px;");
 button.setAttribute("type","submit");







 // ________________________________________________________________________________________________________________________________





var pattern= /^([A-Z\a-z\d\._]+)@([a-z\d]+)\.([a-z]{2,8})(\.[a-z]{2,8})?$/;
var pattern2=/^([A-z\a-z\d\.])?$/;
 // Form Validation 
 function validation(){
     var x=document.getElementById("input1").value;
     var y=document.getElementById("input2").value;
     var z=document.getElementById("input3").value;
     var zz=document.getElementById("input4").value;
      if(x==""){
          alert("Username must be filled ");
          return false;
      }
      if(y==""){
          alert("Email must be filled ");
          return false;
      }
     if(pattern.test(y)==false){
        alert("Email is not valid ");
              return false;
     }
     if(z==""){
alert("Password is not Entered");
return false;
     }
     if(zz==""||zz!=z){
         alert("Password is not same");
         return false;
     }


     

 }


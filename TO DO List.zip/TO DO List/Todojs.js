new Vue({
    el:"#bo",
    data(){
        return {
            tododata:'',
            msg:"TODO LIST"
            ,array:[

                // {name:"first Task"},
                // {name:"Second Task"},
                // {name:"third Task"}
            ],
            // inputbox:"shiv"
            aler:""
        }
    },
    methods:{
        add(){
            if(this.tododata!=''){
            this.array.push({

                name:this.tododata
                
            })
            this.tododata=""
        }
        else{
            this.aler="***Please Enter The Data"
        }
        },
        deleteToDo(i){
            this.array.splice(i,1)
        },

        editToDo(i){
            this.tododata=(this.array[i].name)
            this.array.splice(i,1)
        }
    }
})